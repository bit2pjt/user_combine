package com.spring.boardFree;

public interface BoardFreeDAO {
	
	public int findtitle(String BF_TITLE);
	
}

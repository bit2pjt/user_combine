package com.spring.boardFree;

import java.util.List;

public interface BoardFreeService {

	public List<BoardFreeVO> findtitle();
	
	
}
